import { useEffect, useMemo, useState } from "react";
import "./App.css";

type Operation = "read" | "insert" | "update";
type RunInfo = { run_id?: number | string; job_id?: number | string; state?: string; result_state?: string | null; [key: string]: unknown };
type HistoryItem = { requestId: string; operation: Operation; table: string; runId: string; submittedAt: string; state: string };

const DEFAULT_TABLE = "sp_transmissionmodel.default.transmission_projects";
const sampleRead = `{
  "columns": ["project_id", "project_name", "capacity_mw", "status"],
  "filters": { "project_id": 900001 },
  "limit": 50
}`;
const sampleInsert = `{
  "rows": [
    {
      "project_id": 900002,
      "project_name": "NESO API Test Project",
      "capacity_mw": 275.5,
      "status": "NEW"
    }
  ]
}`;
const sampleUpdate = `{
  "rows": [
    {
      "primary_keys": { "project_id": 900001 },
      "update_data": { "status": "IN_PROGRESS" }
    }
  ]
}`;

function pretty(value: unknown) {
  return JSON.stringify(value, null, 2);
}
function parseJson(text: string, label: string) {
  try { return JSON.parse(text); }
  catch { throw new Error(`${label} is not valid JSON. Check commas, quotes and braces.`); }
}

export default function App() {
  const [apiHealth, setApiHealth] = useState<"checking" | "online" | "offline">("checking");
  const [operation, setOperation] = useState<Operation>("read");
  const [tableName, setTableName] = useState(DEFAULT_TABLE);
  const [requestId, setRequestId] = useState(`NESO-${Date.now()}`);
  const [readJson, setReadJson] = useState(sampleRead);
  const [insertJson, setInsertJson] = useState(sampleInsert);
  const [updateJson, setUpdateJson] = useState(sampleUpdate);
  const [run, setRun] = useState<RunInfo | null>(null);
  const [response, setResponse] = useState<unknown>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [activeNav, setActiveNav] = useState("Operations");
  const [apiBase, setApiBase] = useState("");

  const editorValue = operation === "read" ? readJson : operation === "insert" ? insertJson : updateJson;
  const setEditorValue = operation === "read" ? setReadJson : operation === "insert" ? setInsertJson : setUpdateJson;

  useEffect(() => {
    fetch(`${apiBase}/api/health`)
      .then(r => { if (!r.ok) throw new Error("Health check failed"); return r.json(); })
      .then(() => setApiHealth("online"))
      .catch(() => setApiHealth("offline"));
  }, [apiBase]);

  const payload = useMemo(() => {
    try {
      const detail = parseJson(editorValue, "Operation details");
      return { request_id: requestId, operation, tables: [{ table_name: tableName.trim(), ...detail }] };
    } catch { return null; }
  }, [editorValue, operation, requestId, tableName]);

  async function submitOperation() {
    setError(""); setResponse(null); setRun(null);
    if (!tableName.trim() || tableName.split(".").length !== 3) {
      setError("Enter a fully qualified table name: catalog.schema.table");
      return;
    }
    if (!requestId.trim()) { setError("Request ID is required."); return; }
    if (!payload) { setError("Operation details contain invalid JSON."); return; }
    setBusy(true);
    try {
      const res = await fetch(`${apiBase}/api/execute`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Accept": "application/json" },
        body: JSON.stringify(payload)
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail ? JSON.stringify(data.detail) : `API returned HTTP ${res.status}`);
      setResponse(data);
      const runId = String(data.run_id ?? "");
      const runInfo: RunInfo = { run_id: data.run_id, job_id: data.job_id, state: data.status ?? "SUBMITTED" };
      setRun(runInfo);
      setHistory(prev => [{
        requestId, operation, table: tableName, runId,
        submittedAt: new Date().toLocaleString(), state: String(runInfo.state)
      }, ...prev].slice(0, 20));
      if (!runId) throw new Error("The API response did not contain run_id. Inspect the response below.");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Unable to submit operation.");
    } finally { setBusy(false); }
  }

  async function checkStatus(runId?: string | number) {
    const id = runId ?? run?.run_id;
    if (!id) { setError("No Run ID is available yet."); return; }
    setError("");
    try {
      const res = await fetch(`${apiBase}/api/status/${encodeURIComponent(String(id))}`, { headers: { Accept: "application/json" } });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail ? JSON.stringify(data.detail) : `Status API returned HTTP ${res.status}`);
      setRun(data);
      setResponse(data);
      setHistory(prev => prev.map(item => item.runId === String(id)
        ? { ...item, state: String(data.result_state ?? data.state ?? "UNKNOWN") } : item));
    } catch (e) { setError(e instanceof Error ? e.message : "Unable to retrieve Job status."); }
  }

  async function copyPayload() {
    if (!payload) return;
    try { await navigator.clipboard.writeText(pretty(payload)); }
    catch { setError("Clipboard access is unavailable in this browser."); }
  }

  const statusText = run?.result_state || run?.state || "Not submitted";
  const statusClass = String(statusText).toLowerCase().includes("success") || String(statusText).toLowerCase() === "terminated"
    ? "success" : String(statusText).toLowerCase().includes("fail") ? "danger" : "neutral";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">N</div>
          <div><strong>NESO</strong><span>TRANSMISSION DATA</span></div>
        </div>
        <div className="workspace-label">WORKSPACE</div>
        <nav>
          {["Overview", "Catalog Explorer", "Operations", "Job Monitor", "History"].map(item =>
            <button key={item} className={`nav-item ${activeNav === item ? "active" : ""}`}
              onClick={() => setActiveNav(item)}>
              <span className="nav-icon">{({ Overview: "▦", "Catalog Explorer": "▤", Operations: "⇄", "Job Monitor": "◷", History: "↺" } as Record<string,string>)[item]}</span>
              {item}
            </button>
          )}
        </nav>
        <div className="sidebar-bottom">
          <div className="connection-label">API CONNECTION</div>
          <div className="connection"><i className={apiHealth === "online" ? "dot online" : apiHealth === "offline" ? "dot offline" : "dot"} />{apiHealth === "online" ? "Connected" : apiHealth === "offline" ? "Unavailable" : "Checking..."}</div>
          <label className="base-label" htmlFor="apiBase">API base URL</label>
          <input id="apiBase" value={apiBase} onChange={e => setApiBase(e.target.value.replace(/\/$/, ""))} placeholder="Same app (leave blank)" />
          <small>Leave blank when frontend and API are served by the same Databricks App.</small>
        </div>
      </aside>

      <main className="main">
        <header className="topbar">
          <div><div className="eyebrow">DATA PLATFORM / {activeNav.toUpperCase()}</div><h1>{activeNav === "Operations" ? "Data Operations" : activeNav}</h1></div>
          <div className="top-actions"><span className={`api-pill ${apiHealth}`}><i className="dot" /> API {apiHealth}</span><div className="avatar">EK</div></div>
        </header>

        <section className="intro">
          <div><h2>Manage transmission data</h2><p>Submit metadata-driven read, insert and update operations through your Databricks Job.</p></div>
          <div className="job-chip"><span className="pulse" /> Databricks Job orchestration</div>
        </section>

        <section className="stats-grid">
          <div className="stat-card"><span className="stat-icon blue">▤</span><div><small>Execution model</small><strong>Databricks Jobs</strong></div></div>
          <div className="stat-card"><span className="stat-icon green">✓</span><div><small>Verified operations</small><strong>Read &amp; Update</strong></div></div>
          <div className="stat-card"><span className="stat-icon purple">◇</span><div><small>Data platform</small><strong>Unity Catalog</strong></div></div>
        </section>

        <div className="content-grid">
          <section className="panel operation-panel">
            <div className="panel-heading"><div><h3>New operation</h3><p>Choose an operation and provide its table and request details.</p></div><span className="step-tag">REQUEST BUILDER</span></div>
            <div className="field">
              <label>Operation type</label>
              <div className="operation-tabs">
                {(["read", "insert", "update"] as Operation[]).map(op =>
                  <button key={op} className={operation === op ? "selected" : ""} onClick={() => { setOperation(op); setRequestId(`NESO-${op.toUpperCase()}-${Date.now()}`); }}>
                    <span>{op === "read" ? "⌕" : op === "insert" ? "+" : "✎"}</span>{op.toUpperCase()}
                  </button>
                )}
              </div>
            </div>
            <div className="field"><label htmlFor="tableName">Fully qualified table name</label>
              <input id="tableName" value={tableName} onChange={e => setTableName(e.target.value)} placeholder="catalog.schema.table" />
              <small>Example: sp_transmissionmodel.default.transmission_projects</small>
            </div>
            <div className="field"><label htmlFor="requestId">Request ID</label>
              <input id="requestId" value={requestId} onChange={e => setRequestId(e.target.value)} />
            </div>
            <div className="field">
              <div className="editor-label"><label htmlFor="details">{operation === "read" ? "Read configuration" : operation === "insert" ? "Records to insert" : "Update configuration"}</label><button className="text-button" onClick={() => setEditorValue(operation === "read" ? sampleRead : operation === "insert" ? sampleInsert : sampleUpdate)}>Reset sample</button></div>
              <textarea id="details" className="json-editor" spellCheck={false} value={editorValue} onChange={e => setEditorValue(e.target.value)} />
              <small>{operation === "read" ? "Use columns, filters and limit." : operation === "insert" ? "Provide rows containing the target table's columns." : "Provide primary_keys and update_data for each row."}</small>
            </div>
            {error && <div className="alert error"><strong>Request error</strong><span>{error}</span></div>}
            <div className="form-actions"><button className="secondary-button" onClick={copyPayload} disabled={!payload}>Copy request JSON</button><button className="primary-button" onClick={submitOperation} disabled={busy || !payload}>{busy ? <><span className="spinner" /> Submitting...</> : "Submit operation →"}</button></div>
            <div className="notice"><strong>Execution note</strong><span>Submission is asynchronous. A successful HTTP response means the Job was submitted, not necessarily that the table operation has finished.</span></div>
          </section>

          <section className="right-column">
            <div className="panel run-panel">
              <div className="panel-heading"><div><h3>Execution monitor</h3><p>Track the latest Databricks Job run.</p></div><span className={`status-badge ${statusClass}`}>{String(statusText).replace("RunLifeCycleState.", "")}</span></div>
              {run?.run_id ? <>
                <div className="run-id-block"><small>RUN ID</small><strong>{String(run.run_id)}</strong></div>
                <div className="run-details"><div><small>Job ID</small><strong>{String(run.job_id ?? "—")}</strong></div><div><small>Result state</small><strong>{String(run.result_state ?? "Pending")}</strong></div></div>
                <button className="primary-button full" onClick={() => checkStatus()} >Refresh Job status ↻</button>
                {String(run.state).includes("RUNNING") && <p className="helper">The Job is running. Refresh after a short wait.</p>}
              </> : <div className="empty-state"><div className="empty-icon">◷</div><strong>No active run</strong><span>Submit an operation to see its Job ID, Run ID and execution status here.</span></div>}
            </div>
            <div className="panel response-panel">
              <div className="panel-heading"><div><h3>Latest response</h3><p>API submission or Job status response.</p></div><span className="step-tag">JSON</span></div>
              <pre className="response-code">{response ? pretty(response) : "Response will appear here after you submit an operation."}</pre>
            </div>
          </section>
        </div>

        <section className="panel history-panel">
          <div className="panel-heading"><div><h3>Recent operations</h3><p>Operations submitted during this browser session.</p></div><span className="step-tag">{history.length} RECORDS</span></div>
          {history.length ? <div className="table-wrap"><table><thead><tr><th>REQUEST ID</th><th>OPERATION</th><th>TABLE</th><th>RUN ID</th><th>STATUS</th><th></th></tr></thead><tbody>
            {history.map((item, i) => <tr key={`${item.runId}-${i}`}><td className="mono">{item.requestId}</td><td><span className={`op-tag ${item.operation}`}>{item.operation}</span></td><td className="mono">{item.table}</td><td className="mono">{item.runId || "—"}</td><td>{item.state}</td><td><button className="text-button" onClick={() => checkStatus(item.runId)}>Check status</button></td></tr>)}
          </tbody></table></div> : <div className="history-empty">No operations submitted in this session yet.</div>}
        </section>
        <footer>NESO Transmission Data Platform <span>•</span> API-driven data operations</footer>
      </main>
    </div>
  );
}