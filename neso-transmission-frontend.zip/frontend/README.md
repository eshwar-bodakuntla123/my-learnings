# NESO Transmission Frontend

React + TypeScript + Vite frontend for the existing FastAPI/Databricks Jobs API.

## Included
- Read, insert and update request builder
- POST `/api/execute`
- GET `/api/status/{run_id}` polling/refresh
- API health check at `/api/health`
- Recent operations for the current browser session
- Responsive layout

## Deploy into the existing Databricks App source
Replace the contents of your existing `frontend` folder with this folder's contents.
Keep your existing backend folder and root `app.yaml` / `manifest.yaml`.

The Vite build output is configured to go to `../backend/static`, matching the FastAPI static-file serving pattern used by this project. The App should build the frontend during deployment using the root app build configuration.

## API contract expected
POST `/api/execute` accepts:
{
  "request_id": "...",
  "operation": "read|insert|update",
  "tables": [
    {
      "table_name": "catalog.schema.table",
      "...operation fields...": "..."
    }
  ]
}

GET `/api/status/{run_id}` returns the Databricks run state.

## Important
- API base URL is blank by default, so calls are same-origin (`/api/...`).
- If your backend exposes a different route or payload shape, update `src/App.tsx`.
- The Catalog Explorer navigation item is currently a UI placeholder. Catalog/schema/table discovery is not wired because the current app identity had Unity Catalog discovery permission issues. Do not mistake this UI for completed catalog discovery.
- This is a development frontend. Add authentication/authorization, CSRF/CORS policy as appropriate, server-side validation, audit and idempotency controls before production.
