# Dynamic Unity Catalog + Delta update platform

Starter project: React UI + FastAPI + one reusable Databricks notebook Job. Supports multiple approved tables, multiple records per table, and different partial-update columns per record. No DELETE endpoint.

## Request
POST `/api/v1/tables/batch-update`
```json
{"request_id":"REQ-1","tables":[{"table_name":"main.hr.employees","records":[{"keys":{"employee_id":101},"updates":{"salary":95000}},{"keys":{"employee_id":102},"updates":{"department":"Engineering"}}]},{"table_name":"main.crm.customers","records":[{"keys":{"customer_id":501},"updates":{"city":"Hyderabad"}}]}]}
```
The server registry defines approved tables, primary keys and allowed update columns. Do not let callers authorize themselves with payload fields.

## Local run
Backend: `cd backend && pip install -r requirements.txt`, copy `.env.example` to `.env`, fill local Databricks host/token/job ID/API key, then `uvicorn api.main:app --reload --port 8000`.
Frontend: `cd frontend && npm install && npm run dev`. Open Vite URL. API calls proxy to localhost:8000.

## Databricks deployment
1. Create target UC tables and configure `backend/api/registry.json`.
2. Upload `backend/databricks/dynamic_table_worker.py` to Workspace as a Python notebook.
3. Create ONE Job with that notebook as its task, add notebook parameter `payload_json`, use compatible compute, and set a dedicated Run-as service principal.
4. Grant the Job Run-as identity `USE CATALOG`, `USE SCHEMA`, `SELECT`, and `MODIFY` on each approved table.
5. Build React: `cd frontend && npm install && npm run build`; copy `frontend/dist` to `backend/static`.
6. Deploy backend folder as a Databricks App (or host behind Entra ID in Azure App Service/Container Apps). Configure Job resource/ID and grant app identity permission to run the Job. App identity and Job Run-as identity are separate.
7. Update `app.yaml` with actual Job ID/resource binding, deploy, then test `/health`, `/docs`, UI, and a small update.

Example SQL:
```sql
CREATE SCHEMA IF NOT EXISTS main.hr;
CREATE SCHEMA IF NOT EXISTS main.crm;
CREATE TABLE IF NOT EXISTS main.hr.employees(employee_id BIGINT, employee_name STRING, salary DOUBLE, department STRING, manager_id BIGINT) USING DELTA;
CREATE TABLE IF NOT EXISTS main.crm.customers(customer_id BIGINT, customer_name STRING, city STRING, email STRING, customer_type STRING) USING DELTA;
```

## Important limitations
- Starter auth uses an API key; browser-entered keys are visible. Production must use Entra ID/OAuth/JWT validated server-side, not a shared browser secret.
- The app identity starts Jobs; the Job Run-as identity accesses data.
- Multi-table requests are not atomic. Delta commits are per table/merge; some records can succeed while others fail.
- Worker reports per-record merge execution, not a guaranteed affected-row count. A missing key is a no-op.
- Worker processes records sequentially. For large batches, stage data in a UC Volume/cloud storage and use set-based MERGE instead of notebook parameters.
- Unity Catalog does not enforce primary-key uniqueness. Define key semantics and concurrency controls.
- Add audit persistence, idempotency, rate limits, request size limits, retries, and integration tests before production.
