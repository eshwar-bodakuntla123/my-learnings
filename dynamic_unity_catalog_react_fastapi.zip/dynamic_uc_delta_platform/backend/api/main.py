import os,json
from pathlib import Path
from fastapi import FastAPI,HTTPException,Header,Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from pydantic import BaseModel,Field,ConfigDict
from databricks.sdk import WorkspaceClient

app=FastAPI(title="Dynamic Unity Catalog Delta API",version="1.0")
app.add_middleware(CORSMiddleware,allow_origins=[x.strip() for x in os.getenv("CORS_ORIGINS","http://localhost:5173").split(",")],allow_methods=["*"],allow_headers=["*"])
REG=json.loads((Path(__file__).parent/"registry.json").read_text())
def auth(x_api_key:str|None=Header(default=None)):
    expected=os.getenv("API_KEY")
    if expected and x_api_key!=expected: raise HTTPException(401,"Invalid API key")
def wc():
    h,t=os.getenv("DATABRICKS_HOST"),os.getenv("DATABRICKS_TOKEN")
    return WorkspaceClient(host=h,token=t) if h and t else WorkspaceClient()
class Rec(BaseModel):
    model_config=ConfigDict(extra="forbid")
    keys:dict=Field(min_length=1)
    updates:dict=Field(min_length=1)
class Tbl(BaseModel):
    model_config=ConfigDict(extra="forbid")
    table_name:str
    records:list[Rec]=Field(min_length=1,max_length=500)
class Req(BaseModel):
    model_config=ConfigDict(extra="forbid")
    request_id:str
    tables:list[Tbl]=Field(min_length=1,max_length=50)
@app.get("/health")
def health(): return {"status":"ok"}
@app.get("/api/v1/tables",dependencies=[Depends(auth)])
def tables(): return [{"table_key":k,"table_name":v["full_name"],"primary_keys":v["primary_keys"],"update_allowed":v["update_allowed"]} for k,v in REG.items() if v.get("enabled",True)]
@app.get("/api/v1/tables/{key}/schema",dependencies=[Depends(auth)])
def schema(key:str):
    c=REG.get(key)
    if not c or not c.get("enabled",True): raise HTTPException(404,"Unknown table key")
    try:
        cols=wc().tables.get(full_name=c["full_name"]).columns or []
        return {"table_name":c["full_name"],"primary_keys":c["primary_keys"],"update_allowed":c["update_allowed"],"columns":[{"name":x.name,"type_text":x.type_text,"nullable":x.nullable} for x in cols]}
    except Exception as e: raise HTTPException(502,f"Metadata lookup failed: {e}")
@app.post("/api/v1/tables/batch-update",dependencies=[Depends(auth)])
def update(req:Req):
    body=req.model_dump()
    for t in body["tables"]:
        cfg=next((v for v in REG.values() if v["full_name"].lower()==t["table_name"].lower() and v.get("enabled",True)),None)
        if not cfg: raise HTTPException(403,f"Table not approved: {t['table_name']}")
        for i,r in enumerate(t["records"]):
            if set(r["keys"])!=set(cfg["primary_keys"]): raise HTTPException(422,f"{t['table_name']} row {i}: keys must be {cfg['primary_keys']}")
            if not set(r["updates"])<=set(cfg["update_allowed"]): raise HTTPException(422,f"{t['table_name']} row {i}: update contains unapproved columns")
            if set(r["keys"])&set(r["updates"]): raise HTTPException(422,"Primary keys cannot be updated")
    try:
        job=int(os.environ["DATABRICKS_JOB_ID"])
        run=wc().jobs.run_now(job_id=job,notebook_params={"payload_json":json.dumps(body,separators=(",",":"))})
        return {"run_id":run.run_id,"job_id":job,"state":"PENDING"}
    except Exception as e: raise HTTPException(502,f"Could not start Job: {e}")
@app.get("/api/v1/jobs/{run_id}",dependencies=[Depends(auth)])
def job_status(run_id:int):
    try:
        x=wc().jobs.get_run(run_id=run_id); s=x.state
        return {"run_id":x.run_id,"job_id":x.job_id,"life_cycle_state":s.life_cycle_state.value if s and s.life_cycle_state else None,"result_state":s.result_state.value if s and s.result_state else None,"state_message":s.state_message if s else None}
    except Exception as e: raise HTTPException(502,str(e))
static=Path(__file__).parent.parent/"static"
if static.exists():
    app.mount("/assets",StaticFiles(directory=static/"assets"),name="assets")
    @app.get("/")
    def ui(): return FileResponse(static/"index.html")
