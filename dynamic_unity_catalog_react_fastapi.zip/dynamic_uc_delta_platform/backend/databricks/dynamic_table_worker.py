# Databricks Python notebook source
import json
from delta.tables import DeltaTable
from pyspark.sql import functions as F
from pyspark.sql.types import StructType

dbutils.widgets.text("payload_json","{}")
payload=json.loads(dbutils.widgets.get("payload_json"))
# Execution-side allowlist. Keep aligned with API registry; preferably centralize in governed UC config.
APPROVED={
 "main.hr.employees":{"keys":["employee_id"],"updates":["employee_name","salary","department","manager_id"]},
 "main.crm.customers":{"keys":["customer_id"],"updates":["customer_name","city","email","customer_type"]}
}
def qi(s): return "`"+s.replace("`","``")+"`"
out=[]
for t in payload.get("tables",[]):
 name=t["table_name"]; tr={"table_name":name,"records":[]}
 try:
  if name not in APPROVED: raise ValueError("Table not approved by worker")
  cfg=APPROVED[name]; target=spark.table(name); fields={f.name:f for f in target.schema.fields}
  for i,r in enumerate(t["records"]):
   try:
    keys=r["keys"]; upd=r["updates"]
    if set(keys)!=set(cfg["keys"]): raise ValueError("Primary key mismatch")
    if not upd or not set(upd)<=set(cfg["updates"]): raise ValueError("Unapproved update column")
    missing=(set(keys)|set(upd))-set(fields)
    if missing: raise ValueError("Missing target columns: "+str(sorted(missing)))
    if set(keys)&set(upd): raise ValueError("Cannot update key columns")
    names=list(keys)+list(upd); source_schema=StructType([fields[n] for n in names])
    vals=[keys[n] for n in keys]+[upd[n] for n in upd]
    src=spark.createDataFrame([tuple(vals)],schema=source_schema)
    cond=" AND ".join([f"t.{qi(k)} = s.{qi(k)}" for k in keys])
    sets={c:F.col("s."+qi(c)) for c in upd}
    DeltaTable.forName(spark,name).alias("t").merge(src.alias("s"),cond).whenMatchedUpdate(set=sets).execute()
    tr["records"].append({"record_index":i,"status":"merge_executed","note":"Existing matching row updated; no insert"})
   except Exception as e: tr["records"].append({"record_index":i,"status":"failed","error":str(e)})
 except Exception as e: tr["table_error"]=str(e)
 out.append(tr)
dbutils.notebook.exit(json.dumps({"request_id":payload.get("request_id"),"table_results":out,"warning":"Multi-table updates are not atomic; inspect every row result."},default=str))
